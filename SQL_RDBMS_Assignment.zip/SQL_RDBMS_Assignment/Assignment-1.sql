Select d.DeptName as Department,
Min(Salary) as MinimumSalary,
Max(Salary) as MaximumSalary,
AvG(Salary) as AverageSalary
from Employees e join Department d on e.DID=d.DID group by d.DeptName;

Select d.DeptName,count(e.ID)as TotalEmployees
from Employees e join Department d on 
e.ID=d.DID group  by d.DeptName

select d.DeptName,Sum(e.Salary) as TotalSalary 
from Employees e join Department d on 
d.DID=e.ID group by d.DeptName;